export const environment = {
  apiUrl : 'https://tribu-ti-staffing-desarrollo-afangwbmcrhucqfh.z01.azurefd.net/ipf-msa-productosfinancieros',
  authorId: '427'
  // authorId: '1'
};
